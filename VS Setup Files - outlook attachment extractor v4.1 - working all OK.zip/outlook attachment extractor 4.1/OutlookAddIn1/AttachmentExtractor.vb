﻿Imports Microsoft.Office.Interop.Outlook
Imports OutlookAddIn1.FrmMain
Imports OutlookAddIn1.globalVar

Public Class AttachmentExtractor

    'Public Shared OlApp As [NameSpace]
    'Public Shared ons As Outlook.NameSpace
    Dim outlookNameSpace As Outlook.NameSpace
    Dim inbox As Outlook.MAPIFolder
    Dim WithEvents items As Outlook.Items

    Private Sub ThisAddIn_Startup() Handles Me.Startup
        outlookNameSpace = Me.Application.GetNamespace("MAPI")
        inbox = outlookNameSpace.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderInbox)
        items = inbox.Items

        loadMailbox()

    End Sub

    Public Sub loadMailbox()
        Dim OlFolder1 As Folder = Nothing
        Dim OlFolder2 As Folder = Nothing
        Dim OlFolder3 As Folder = Nothing

        Dim mainFrm As New FrmMain()

        With mainFrm
            ns = Me.Application.GetNamespace("MAPI")
            .cmbxRetriveFrom.Items.Clear()
            .cmbxMoveTo.Items.Clear()
            .cmbxRetriveFrom.Items.Add("None")
            .cmbxMoveTo.Items.Add("None")

            For Each OlFolder1 In ns.Folders
                If OlFolder1.Name <> "None" Then
                    For Each OlFolder2 In ns.Folders(OlFolder1.Name).Folders
                        If LCase(OlFolder2.Name) Like "*inbox*" Then
                            .cmbxRetriveFrom.Items.Add(OlFolder1.Name & ">>" & OlFolder2.Name)
                            .cmbxMoveTo.Items.Add(OlFolder1.Name & ">>" & OlFolder2.Name)
                            For Each OlFolder3 In ns.Folders(OlFolder1.Name).Folders(OlFolder2.Name).Folders
                                If OlFolder3.Name <> "" Then
                                    .cmbxRetriveFrom.Items.Add(OlFolder1.Name & ">>" & OlFolder2.Name & ">>" & OlFolder3.Name)
                                    .cmbxMoveTo.Items.Add(OlFolder1.Name & ">>" & OlFolder2.Name & ">>" & OlFolder3.Name)
                                End If
                            Next OlFolder3
                        End If
                    Next OlFolder2
                End If
            Next OlFolder1

            If .cmbxRetriveFrom.Items.Count > 0 Then .cmbxRetriveFrom.SelectedIndex = 1
            .cmbxMoveTo.SelectedIndex = 0

            OlFolder1 = Nothing
            OlFolder2 = Nothing
            OlFolder3 = Nothing

            .Show()
            .MaximizeBox = False

        End With

    End Sub
    Private Sub Items_ItemAdd(ByVal item As Object) Handles items.ItemAdd
        If TypeOf (item) Is Outlook.MailItem Then
            Dim mail As Outlook.MailItem = item

            If mail.MessageClass = "IPM.Note" Then
                modMain.extractAttachment(,
                        True, mail)

            End If
        End If
    End Sub


    Private Sub Application_ItemLoad(Item As Object) Handles Application.ItemLoad
        'MsgBox(Item.GetType.FullName)

    End Sub


    Private Sub ThisAddIn_Shutdown() Handles Me.Shutdown



    End Sub

End Class

