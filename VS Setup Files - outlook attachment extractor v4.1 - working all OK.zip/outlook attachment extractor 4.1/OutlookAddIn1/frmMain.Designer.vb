﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMain))
        Me.ExtractEmailAttachments = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txbx_FromEmailFilter = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txbx_AttchContans = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txbx_SubjectFilter = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txbx_folderLoc = New System.Windows.Forms.TextBox()
        Me.ckbDownloadAttachment = New System.Windows.Forms.CheckBox()
        Me.ckbxSaveasMSG = New System.Windows.Forms.CheckBox()
        Me.txbxNewName = New System.Windows.Forms.TextBox()
        Me.cmbx_SaveFileAs = New System.Windows.Forms.ComboBox()
        Me.chkBx_ReplaceExistingFile = New System.Windows.Forms.CheckBox()
        Me.btn_refreshall = New System.Windows.Forms.Button()
        Me.ckbxExact = New System.Windows.Forms.CheckBox()
        Me.ckbxCaseSensitive = New System.Windows.Forms.CheckBox()
        Me.dtFrom = New System.Windows.Forms.DateTimePicker()
        Me.dtTo = New System.Windows.Forms.DateTimePicker()
        Me.ckbxAllFrom = New System.Windows.Forms.CheckBox()
        Me.ckbxAllTo = New System.Windows.Forms.CheckBox()
        Me.label11 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ckbxAutoLoad = New System.Windows.Forms.CheckBox()
        Me.Bt_CopyLog = New System.Windows.Forms.Button()
        Me.cmbxRetriveFrom = New System.Windows.Forms.ComboBox()
        Me.cmbxMoveTo = New System.Windows.Forms.ComboBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'ExtractEmailAttachments
        '
        Me.ExtractEmailAttachments.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExtractEmailAttachments.Location = New System.Drawing.Point(549, 73)
        Me.ExtractEmailAttachments.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ExtractEmailAttachments.Name = "ExtractEmailAttachments"
        Me.ExtractEmailAttachments.Size = New System.Drawing.Size(106, 53)
        Me.ExtractEmailAttachments.TabIndex = 0
        Me.ExtractEmailAttachments.Text = "Extract Email "
        Me.ExtractEmailAttachments.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Olive
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(13, 152)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(728, 22)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Filter Settings"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Silver
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(15, 218)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(122, 22)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "from email"
        '
        'txbx_FromEmailFilter
        '
        Me.txbx_FromEmailFilter.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txbx_FromEmailFilter.Location = New System.Drawing.Point(157, 218)
        Me.txbx_FromEmailFilter.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txbx_FromEmailFilter.Name = "txbx_FromEmailFilter"
        Me.txbx_FromEmailFilter.Size = New System.Drawing.Size(585, 22)
        Me.txbx_FromEmailFilter.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Silver
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label5.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(15, 275)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(122, 22)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "attachment name"
        '
        'txbx_AttchContans
        '
        Me.txbx_AttchContans.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txbx_AttchContans.Location = New System.Drawing.Point(157, 275)
        Me.txbx_AttchContans.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txbx_AttchContans.Name = "txbx_AttchContans"
        Me.txbx_AttchContans.Size = New System.Drawing.Size(585, 22)
        Me.txbx_AttchContans.TabIndex = 10
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Silver
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label6.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(15, 246)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(122, 22)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "subject "
        '
        'txbx_SubjectFilter
        '
        Me.txbx_SubjectFilter.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txbx_SubjectFilter.Location = New System.Drawing.Point(157, 246)
        Me.txbx_SubjectFilter.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txbx_SubjectFilter.Name = "txbx_SubjectFilter"
        Me.txbx_SubjectFilter.Size = New System.Drawing.Size(585, 22)
        Me.txbx_SubjectFilter.TabIndex = 12
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Silver
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(15, 305)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(122, 22)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "from date:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(475, 308)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 16)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "to date:"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Olive
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label9.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(14, 361)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(727, 23)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Attachment/Output File Settings"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Silver
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label10.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(15, 399)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(122, 22)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "export path"
        '
        'txbx_folderLoc
        '
        Me.txbx_folderLoc.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txbx_folderLoc.Location = New System.Drawing.Point(157, 399)
        Me.txbx_folderLoc.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txbx_folderLoc.Name = "txbx_folderLoc"
        Me.txbx_folderLoc.Size = New System.Drawing.Size(450, 22)
        Me.txbx_folderLoc.TabIndex = 19
        '
        'ckbDownloadAttachment
        '
        Me.ckbDownloadAttachment.AutoSize = True
        Me.ckbDownloadAttachment.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ckbDownloadAttachment.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ckbDownloadAttachment.Location = New System.Drawing.Point(645, 37)
        Me.ckbDownloadAttachment.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ckbDownloadAttachment.Name = "ckbDownloadAttachment"
        Me.ckbDownloadAttachment.Size = New System.Drawing.Size(96, 20)
        Me.ckbDownloadAttachment.TabIndex = 21
        Me.ckbDownloadAttachment.Text = "attachment"
        Me.ckbDownloadAttachment.UseVisualStyleBackColor = True
        '
        'ckbxSaveasMSG
        '
        Me.ckbxSaveasMSG.AutoSize = True
        Me.ckbxSaveasMSG.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ckbxSaveasMSG.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ckbxSaveasMSG.Location = New System.Drawing.Point(506, 37)
        Me.ckbxSaveasMSG.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ckbxSaveasMSG.Name = "ckbxSaveasMSG"
        Me.ckbxSaveasMSG.Size = New System.Drawing.Size(112, 20)
        Me.ckbxSaveasMSG.TabIndex = 22
        Me.ckbxSaveasMSG.Text = "save .msg file"
        Me.ckbxSaveasMSG.UseVisualStyleBackColor = True
        '
        'txbxNewName
        '
        Me.txbxNewName.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txbxNewName.Location = New System.Drawing.Point(452, 433)
        Me.txbxNewName.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txbxNewName.Name = "txbxNewName"
        Me.txbxNewName.Size = New System.Drawing.Size(155, 22)
        Me.txbxNewName.TabIndex = 23
        '
        'cmbx_SaveFileAs
        '
        Me.cmbx_SaveFileAs.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbx_SaveFileAs.FormattingEnabled = True
        Me.cmbx_SaveFileAs.Location = New System.Drawing.Point(159, 431)
        Me.cmbx_SaveFileAs.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cmbx_SaveFileAs.Name = "cmbx_SaveFileAs"
        Me.cmbx_SaveFileAs.Size = New System.Drawing.Size(272, 24)
        Me.cmbx_SaveFileAs.TabIndex = 24
        '
        'chkBx_ReplaceExistingFile
        '
        Me.chkBx_ReplaceExistingFile.AutoSize = True
        Me.chkBx_ReplaceExistingFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkBx_ReplaceExistingFile.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBx_ReplaceExistingFile.Location = New System.Drawing.Point(613, 401)
        Me.chkBx_ReplaceExistingFile.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkBx_ReplaceExistingFile.Name = "chkBx_ReplaceExistingFile"
        Me.chkBx_ReplaceExistingFile.Size = New System.Drawing.Size(124, 20)
        Me.chkBx_ReplaceExistingFile.TabIndex = 26
        Me.chkBx_ReplaceExistingFile.Text = "replace existing"
        Me.chkBx_ReplaceExistingFile.UseVisualStyleBackColor = True
        '
        'btn_refreshall
        '
        Me.btn_refreshall.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_refreshall.Location = New System.Drawing.Point(14, 37)
        Me.btn_refreshall.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn_refreshall.Name = "btn_refreshall"
        Me.btn_refreshall.Size = New System.Drawing.Size(123, 24)
        Me.btn_refreshall.TabIndex = 27
        Me.btn_refreshall.Text = "refresh all"
        Me.btn_refreshall.UseVisualStyleBackColor = True
        '
        'ckbxExact
        '
        Me.ckbxExact.AutoSize = True
        Me.ckbxExact.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ckbxExact.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ckbxExact.Location = New System.Drawing.Point(506, 184)
        Me.ckbxExact.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ckbxExact.Name = "ckbxExact"
        Me.ckbxExact.Size = New System.Drawing.Size(101, 20)
        Me.ckbxExact.TabIndex = 28
        Me.ckbxExact.Text = "exact match"
        Me.ckbxExact.UseVisualStyleBackColor = True
        '
        'ckbxCaseSensitive
        '
        Me.ckbxCaseSensitive.AutoSize = True
        Me.ckbxCaseSensitive.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ckbxCaseSensitive.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ckbxCaseSensitive.Location = New System.Drawing.Point(624, 184)
        Me.ckbxCaseSensitive.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ckbxCaseSensitive.Name = "ckbxCaseSensitive"
        Me.ckbxCaseSensitive.Size = New System.Drawing.Size(115, 20)
        Me.ckbxCaseSensitive.TabIndex = 29
        Me.ckbxCaseSensitive.Text = "case sensitive"
        Me.ckbxCaseSensitive.UseVisualStyleBackColor = True
        '
        'dtFrom
        '
        Me.dtFrom.Location = New System.Drawing.Point(157, 305)
        Me.dtFrom.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtFrom.Name = "dtFrom"
        Me.dtFrom.Size = New System.Drawing.Size(141, 22)
        Me.dtFrom.TabIndex = 30
        '
        'dtTo
        '
        Me.dtTo.Location = New System.Drawing.Point(552, 305)
        Me.dtTo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtTo.Name = "dtTo"
        Me.dtTo.Size = New System.Drawing.Size(141, 22)
        Me.dtTo.TabIndex = 31
        '
        'ckbxAllFrom
        '
        Me.ckbxAllFrom.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ckbxAllFrom.Location = New System.Drawing.Point(304, 305)
        Me.ckbxAllFrom.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ckbxAllFrom.Name = "ckbxAllFrom"
        Me.ckbxAllFrom.Size = New System.Drawing.Size(48, 22)
        Me.ckbxAllFrom.TabIndex = 32
        Me.ckbxAllFrom.Text = "all"
        Me.ckbxAllFrom.UseVisualStyleBackColor = True
        '
        'ckbxAllTo
        '
        Me.ckbxAllTo.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ckbxAllTo.Location = New System.Drawing.Point(699, 305)
        Me.ckbxAllTo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ckbxAllTo.Name = "ckbxAllTo"
        Me.ckbxAllTo.Size = New System.Drawing.Size(48, 22)
        Me.ckbxAllTo.TabIndex = 33
        Me.ckbxAllTo.Text = "all"
        Me.ckbxAllTo.UseVisualStyleBackColor = True
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.label11.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label11.Location = New System.Drawing.Point(408, 482)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(123, 18)
        Me.label11.TabIndex = 51
        Me.label11.Text = "more automations"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(541, 482)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 18)
        Me.Label1.TabIndex = 52
        Me.Label1.Text = "email me"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label12.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(689, 482)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(54, 18)
        Me.Label12.TabIndex = 54
        Me.Label12.Text = "donate"
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.Olive
        Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label13.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(13, 9)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(733, 22)
        Me.Label13.TabIndex = 55
        Me.Label13.Text = "Mail Box"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Silver
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label14.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(15, 433)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(122, 22)
        Me.Label14.TabIndex = 56
        Me.Label14.Text = "attachment name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(613, 482)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 18)
        Me.Label2.TabIndex = 53
        Me.Label2.Text = "visit fiverr"
        '
        'ckbxAutoLoad
        '
        Me.ckbxAutoLoad.BackColor = System.Drawing.Color.Gray
        Me.ckbxAutoLoad.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ckbxAutoLoad.Location = New System.Drawing.Point(669, 74)
        Me.ckbxAutoLoad.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ckbxAutoLoad.Name = "ckbxAutoLoad"
        Me.ckbxAutoLoad.Size = New System.Drawing.Size(74, 48)
        Me.ckbxAutoLoad.TabIndex = 57
        Me.ckbxAutoLoad.Text = "Auto Run"
        Me.ckbxAutoLoad.UseVisualStyleBackColor = False
        '
        'Bt_CopyLog
        '
        Me.Bt_CopyLog.AutoSize = True
        Me.Bt_CopyLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Bt_CopyLog.ForeColor = System.Drawing.Color.White
        Me.Bt_CopyLog.Location = New System.Drawing.Point(795, 512)
        Me.Bt_CopyLog.Margin = New System.Windows.Forms.Padding(4)
        Me.Bt_CopyLog.Name = "Bt_CopyLog"
        Me.Bt_CopyLog.Size = New System.Drawing.Size(83, 30)
        Me.Bt_CopyLog.TabIndex = 61
        Me.Bt_CopyLog.Text = "Copy Log"
        Me.Bt_CopyLog.UseVisualStyleBackColor = False
        Me.Bt_CopyLog.Visible = False
        '
        'cmbxRetriveFrom
        '
        Me.cmbxRetriveFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbxRetriveFrom.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbxRetriveFrom.FormattingEnabled = True
        Me.cmbxRetriveFrom.Location = New System.Drawing.Point(153, 74)
        Me.cmbxRetriveFrom.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cmbxRetriveFrom.Name = "cmbxRetriveFrom"
        Me.cmbxRetriveFrom.Size = New System.Drawing.Size(381, 24)
        Me.cmbxRetriveFrom.TabIndex = 62
        '
        'cmbxMoveTo
        '
        Me.cmbxMoveTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbxMoveTo.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbxMoveTo.FormattingEnabled = True
        Me.cmbxMoveTo.Location = New System.Drawing.Point(153, 102)
        Me.cmbxMoveTo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cmbxMoveTo.Name = "cmbxMoveTo"
        Me.cmbxMoveTo.Size = New System.Drawing.Size(381, 24)
        Me.cmbxMoveTo.TabIndex = 63
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.Silver
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label15.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(15, 76)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(122, 22)
        Me.Label15.TabIndex = 64
        Me.Label15.Text = "Retrive from"
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Silver
        Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label16.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(15, 104)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(122, 22)
        Me.Label16.TabIndex = 65
        Me.Label16.Text = "Move to"
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkGray
        Me.ClientSize = New System.Drawing.Size(751, 509)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.cmbxMoveTo)
        Me.Controls.Add(Me.cmbxRetriveFrom)
        Me.Controls.Add(Me.Bt_CopyLog)
        Me.Controls.Add(Me.ckbxAutoLoad)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.label11)
        Me.Controls.Add(Me.ckbxAllTo)
        Me.Controls.Add(Me.ckbxAllFrom)
        Me.Controls.Add(Me.dtTo)
        Me.Controls.Add(Me.dtFrom)
        Me.Controls.Add(Me.ckbxCaseSensitive)
        Me.Controls.Add(Me.ckbxExact)
        Me.Controls.Add(Me.btn_refreshall)
        Me.Controls.Add(Me.chkBx_ReplaceExistingFile)
        Me.Controls.Add(Me.cmbx_SaveFileAs)
        Me.Controls.Add(Me.txbxNewName)
        Me.Controls.Add(Me.ckbxSaveasMSG)
        Me.Controls.Add(Me.ckbDownloadAttachment)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txbx_folderLoc)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txbx_SubjectFilter)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txbx_AttchContans)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txbx_FromEmailFilter)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ExtractEmailAttachments)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "FrmMain"
        Me.Text = "Change info"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ExtractEmailAttachments As Windows.Forms.Button
    Friend WithEvents Label3 As Windows.Forms.Label
    Friend WithEvents Label4 As Windows.Forms.Label
    Friend WithEvents txbx_FromEmailFilter As Windows.Forms.TextBox
    Friend WithEvents Label5 As Windows.Forms.Label
    Friend WithEvents txbx_AttchContans As Windows.Forms.TextBox
    Friend WithEvents Label6 As Windows.Forms.Label
    Friend WithEvents txbx_SubjectFilter As Windows.Forms.TextBox
    Friend WithEvents Label7 As Windows.Forms.Label
    Friend WithEvents Label8 As Windows.Forms.Label
    Friend WithEvents Label9 As Windows.Forms.Label
    Friend WithEvents Label10 As Windows.Forms.Label
    Friend WithEvents txbx_folderLoc As Windows.Forms.TextBox
    Friend WithEvents ckbDownloadAttachment As Windows.Forms.CheckBox
    Friend WithEvents ckbxSaveasMSG As Windows.Forms.CheckBox
    Friend WithEvents txbxNewName As Windows.Forms.TextBox
    Friend WithEvents cmbx_SaveFileAs As Windows.Forms.ComboBox
    Friend WithEvents chkBx_ReplaceExistingFile As Windows.Forms.CheckBox
    Friend WithEvents btn_refreshall As Windows.Forms.Button
    Friend WithEvents ckbxExact As Windows.Forms.CheckBox
    Friend WithEvents ckbxCaseSensitive As Windows.Forms.CheckBox
    Friend WithEvents dtFrom As Windows.Forms.DateTimePicker
    Friend WithEvents dtTo As Windows.Forms.DateTimePicker
    Friend WithEvents ckbxAllFrom As Windows.Forms.CheckBox
    Friend WithEvents ckbxAllTo As Windows.Forms.CheckBox
    Friend WithEvents label11 As Windows.Forms.Label
    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents Label12 As Windows.Forms.Label
    Friend WithEvents Label13 As Windows.Forms.Label
    Friend WithEvents Label14 As Windows.Forms.Label
    Friend WithEvents Label2 As Windows.Forms.Label
    Friend WithEvents ckbxAutoLoad As Windows.Forms.CheckBox
    Friend WithEvents Bt_CopyLog As Windows.Forms.Button
    Friend WithEvents cmbxRetriveFrom As Windows.Forms.ComboBox
    Friend WithEvents cmbxMoveTo As Windows.Forms.ComboBox
    Friend WithEvents Label15 As Windows.Forms.Label
    Friend WithEvents Label16 As Windows.Forms.Label
End Class
