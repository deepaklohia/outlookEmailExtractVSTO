﻿Imports OutlookAddIn1.modMain.globalVar

Public Class FrmMain
    Public Sub frmOutlookControl_Load(sender As Object, e As EventArgs) Handles Me.Load

        Me.Text = "Outlook Email Extractor v1.5"
        Me.CenterToScreen()
        Call RefreshAll()
    End Sub

    Public Sub RefreshAll(Optional refreshMailbox As Boolean = False)
        With Me
            .ckbxAutoLoad.Checked = False

            .Label4.Text = "from email contains"
            .Label6.Text = "subject contains"
            .Label5.Text = "attachment contains"
            .dtFrom.Text = Now
            .dtTo.Text = Now
            .ckbxAllFrom.Checked = True
            .ckbxAllTo.Checked = True
            .txbx_FromEmailFilter.Text = "*"
            .txbx_SubjectFilter.Text = "*"
            .txbx_AttchContans.Text = "*"
            .ckbDownloadAttachment.Checked = True
            .ckbxCaseSensitive.Checked = False
            .ckbxExact.Checked = False
            .txbxNewName.Text = "_New"

            .chkBx_ReplaceExistingFile.Checked = False
            .ckbxSaveasMSG.Checked = False

            .txbx_folderLoc.Text = rootPath & "\Extract"
            Try
                If Dir(.txbx_folderLoc.Text, vbDirectory) = "" Then MkDir(.txbx_folderLoc.Text)
            Catch ex As Exception
                MsgBox("unable to create folder :  " & .txbx_folderLoc.Text)
            End Try

            Call loadDropDownValues()
            If refreshMailbox = True Then reloadMailbox()
        End With

    End Sub
    Public Sub reloadMailbox()

        Dim OlFolder1 As Outlook.Folder = Nothing
        Dim OlFolder2 As Outlook.Folder = Nothing
        Dim OlFolder3 As Outlook.Folder = Nothing
        Dim ns As Outlook.NameSpace
        Dim OlApp As Outlook.Application

        Try
            OlApp = GetObject(, "Outlook.Application")
        Catch
            OlApp = New Outlook.Application()
        End Try

        ns = OlApp.GetNamespace("MAPI")

        With Me
            .cmbxRetriveFrom.Items.Clear()
            .cmbxMoveTo.Items.Clear()
            .cmbxRetriveFrom.Items.Add("None")
            .cmbxMoveTo.Items.Add("None")

            For Each OlFolder1 In ns.Folders
                If OlFolder1.Name <> "None" Then
                    For Each OlFolder2 In ns.Folders(OlFolder1.Name).Folders
                        If LCase(OlFolder2.Name) Like "*inbox*" Then
                            .cmbxRetriveFrom.Items.Add(OlFolder1.Name & ">>" & OlFolder2.Name)
                            .cmbxMoveTo.Items.Add(OlFolder1.Name & ">>" & OlFolder2.Name)
                            For Each OlFolder3 In ns.Folders(OlFolder1.Name).Folders(OlFolder2.Name).Folders
                                If OlFolder3.Name <> "" Then
                                    .cmbxRetriveFrom.Items.Add(OlFolder1.Name & ">>" & OlFolder2.Name & ">>" & OlFolder3.Name)
                                    .cmbxMoveTo.Items.Add(OlFolder1.Name & ">>" & OlFolder2.Name & ">>" & OlFolder3.Name)
                                End If
                            Next OlFolder3
                        End If
                    Next OlFolder2
                End If
            Next OlFolder1

            If .cmbxRetriveFrom.Items.Count > 0 Then .cmbxRetriveFrom.SelectedIndex = 1
            .cmbxMoveTo.SelectedIndex = 0
        End With


        OlFolder1 = Nothing
        OlFolder2 = Nothing
        OlFolder3 = Nothing


    End Sub
    Public Sub loadDropDownValues()
        With Me.cmbx_SaveFileAs.Items
            .Clear()
            .Add("Original Name")
            .Add("New Name")
            .Add("Original_ + New Name")
            .Add("New_ + Original Name")
            .Add("SenderName")
            .Add("SenderName_ + Original Name")
            .Add("SenderEmail")
            .Add("SenderEmail_ + Original Name")
        End With
        Me.cmbx_SaveFileAs.Text = "Original Name"
    End Sub



    Public Sub frmMain_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        Me.cmbxRetriveFrom.Text = Global_txbxRetriveFrom
        Me.cmbxMoveTo.Text = Global_txbxMoveTo
    End Sub

    Private Sub ExtractEmailAttachments_Click(sender As Object, e As EventArgs) Handles ExtractEmailAttachments.Click
        'If modMain.checkSubscription(False) = False Then Exit Sub

        Dim fromDate As String = "*"
        Dim toDate As String = "*"
        If Me.ckbxAllFrom.Checked = False Then fromDate = Me.dtFrom.Text
        If Me.ckbxAllTo.Checked = False Then toDate = Me.dtTo.Text

        setGlobalValues()
        modMain.extractAttachment()

    End Sub



    Private Sub btn_refreshall_Click(sender As Object, e As EventArgs) Handles btn_refreshall.Click
        Call RefreshAll(True)
    End Sub

    Private Sub ckbxExact_CheckedChanged(sender As Object, e As EventArgs) Handles ckbxExact.CheckedChanged

        Global_ckbxExact = Me.ckbxExact.Checked

        If Me.ckbxExact.Checked = True Then
            Me.Label4.Text = "from email"
            Me.Label6.Text = "subject name"
            Me.Label5.Text = "attachment name"
        Else
            Me.Label4.Text = "from email contains"
            Me.Label6.Text = "subject contains"
            Me.Label5.Text = "attachment contains"
        End If

    End Sub

    Private Sub ckbxAllTo_CheckedChanged(sender As Object, e As EventArgs) Handles ckbxAllTo.CheckedChanged

        Global_ckbxAllTo = Me.ckbxAllTo.Checked

        If Me.ckbxAllTo.Checked = True Then
            Me.dtTo.Enabled = False
        Else
            Me.dtTo.Enabled = True
        End If

    End Sub

    Private Sub ckbxAllFrom_CheckedChanged(sender As Object, e As EventArgs) Handles ckbxAllFrom.CheckedChanged

        Global_ckbxAllFrom = Me.ckbxAllFrom.Checked

        If Me.ckbxAllFrom.Checked = True Then
            Me.dtFrom.Enabled = False
        Else
            Me.dtFrom.Enabled = True
        End If
    End Sub

    Private Sub cmbx_SaveFileAs_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbx_SaveFileAs.SelectedIndexChanged
        If Me.cmbx_SaveFileAs.Text Like "*New Name*" Then
            Me.txbxNewName.Visible = True
        Else
            Me.txbxNewName.Visible = False
        End If
    End Sub



    Private Sub label11_Click_1(sender As Object, e As EventArgs) Handles label11.Click
        Dim url As String = "https://www.youtube.com/channel/UCfw5bPQzVXGt5swIOWVQz8Q?sub_confirmation=1"

        Try
            System.Diagnostics.Process.Start(url)
        Catch ex As Exception
            MsgBox("error opening url , visit www.DeepakLohia.com")
        End Try
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        Dim url As String = "mailto:deepak9delhi@gmail.com"

        Try
            System.Diagnostics.Process.Start(url)
        Catch ex As Exception
            MsgBox("error opening url , visit www.DeepakLohia.com")
        End Try
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        Dim url As String = "https://www.fiverr.com/deepaklohia"

        Try
            System.Diagnostics.Process.Start(url)
        Catch ex As Exception
            MsgBox("error opening url , visit www.DeepakLohia.com")
        End Try
    End Sub


    Private Sub Label12_Click(sender As Object, e As EventArgs) Handles Label12.Click
        Dim url As String = "https://www.paypal.me/deepaklohia"

        Try
            System.Diagnostics.Process.Start(url)
        Catch ex As Exception
            MsgBox("error opening url , visit www.DeepakLohia.com")
        End Try
    End Sub

    Sub setGlobalValues()

        'ASSIGN SHARED VARIABLES


        Global_ckbxSaveasMSG = Me.ckbxSaveasMSG.Checked
        Global_ckbDownloadAttachment = Me.ckbDownloadAttachment.Checked

        Global_txbxRetriveFrom = Me.cmbxRetriveFrom.Text
        Global_txbxMoveTo = Me.cmbxMoveTo.Text

        Global_ckbxExact = Me.ckbxExact.Checked
        Global_ckbxCaseSensitive = Me.ckbxCaseSensitive.Checked

        Global_txbx_FromEmailFilter = Trim(Me.txbx_FromEmailFilter.Text)
        Global_txbx_SubjectFilter = Trim(Me.txbx_SubjectFilter.Text)
        Global_txbx_AttchContans = Trim(Me.txbx_AttchContans.Text)

        Global_ckbxAllFrom = Me.ckbxAllFrom.Checked
        Global_ckbxAllTo = Me.ckbxAllTo.Checked

        If Global_ckbxAllFrom = False Then
            Global_dtFrom = Me.dtFrom.Text
        Else
            Global_dtFrom = "*"
        End If

        If Global_ckbxAllTo = False Then
            Global_dtTo = Me.dtTo.Text
        Else
            Global_dtTo = "*"
        End If

        Global_txbx_folderLoc = Me.txbx_folderLoc.Text
        Global_chkBx_ReplaceExistingFile = Me.chkBx_ReplaceExistingFile.Checked
        Global_cmbx_SaveFileAs = Me.cmbx_SaveFileAs.Text
        Global_txbxNewName = Me.txbxNewName.Text


        If Global_txbxRetriveFrom = "" Then Global_txbxRetriveFrom = "None"
        If Global_txbxMoveTo = "" Then Global_txbxMoveTo = "None"

        If Global_txbx_SubjectFilter = "" Then Global_txbx_SubjectFilter = "*"
        If Global_txbx_FromEmailFilter = "" Then Global_txbx_FromEmailFilter = "*"
        If Global_txbx_AttchContans = "" Then Global_txbx_AttchContans = "*"

    End Sub

    Private Sub ckbxAutoLoad_CheckedChanged(sender As Object, e As EventArgs) Handles ckbxAutoLoad.CheckedChanged

        setGlobalValues()

        If Me.ckbxAutoLoad.Checked = True Then
            If modMain.extractAttachment(True) = True Then
                Global_ckbxAutoLoad = True
            Else
                Me.ckbxAutoLoad.Checked = False
                Global_ckbxAutoLoad = False
            End If
        ElseIf Me.ckbxAutoLoad.Checked = False Then
            Global_ckbxAutoLoad = False
        End If
    End Sub

    Private Sub ckbxSaveasMSG_CheckedChanged(sender As Object, e As EventArgs) Handles ckbxSaveasMSG.CheckedChanged


        If Me.ckbxSaveasMSG.Checked = False And
            Me.ckbDownloadAttachment.Checked = False Then
            Me.ckbDownloadAttachment.Checked = True
        End If

        Global_ckbxSaveasMSG = Me.ckbxSaveasMSG.Checked
    End Sub

    Private Sub ckbDownloadAttachment_CheckedChanged(sender As Object, e As EventArgs) Handles ckbDownloadAttachment.CheckedChanged

        If Me.ckbDownloadAttachment.Checked = False And
            Me.ckbxSaveasMSG.Checked = False Then
            Me.ckbxSaveasMSG.Checked = True

            Me.cmbx_SaveFileAs.Enabled = False
            Me.txbxNewName.Enabled = False
        Else
            Me.cmbx_SaveFileAs.Enabled = True
            Me.txbxNewName.Enabled = True
        End If

        Global_ckbDownloadAttachment = Me.ckbDownloadAttachment.Checked
    End Sub

    Private Sub ckbxCase_CheckedChanged(sender As Object, e As EventArgs) Handles ckbxCaseSensitive.CheckedChanged
        Global_ckbxCaseSensitive = Me.ckbxCaseSensitive.Checked
    End Sub

    Private Sub dtFrom_ValueChanged(sender As Object, e As EventArgs) Handles dtFrom.ValueChanged
        'global_ dtFrom = Me.dtFrom.Text

    End Sub

    'Public Sub updateLog(NewLine As Boolean, LogMsg As String)

    '    With Me
    '        If LogMsg = "START>>" Then

    '            .Txt_Log.AppendText(vbNewLine)
    '            .Txt_Log.AppendText("----------------------------------------------------------------------------------------------------------------------------------")
    '            .Txt_Log.AppendText(vbNewLine & "START>>" & " " & Format(Now(), "hh:mm:ss tt"))
    '            .Txt_Log.ForeColor = Color.FromArgb(182, 182, 0)
    '            .lbl_mainStatsBar.Text = "Processing..."
    '        ElseIf LogMsg = "<<END" Then
    '            .lbl_mainStatsBar.Text = "Ready"
    '        Else
    '            If NewLine = True Then
    '                .Txt_Log.AppendText(vbNewLine & LogMsg)
    '            Else
    '                .Txt_Log.AppendText(LogMsg)
    '            End If
    '            If InStr(LogMsg, "DONE") = 0 Then .lbl_mainStatsBar.Text = LogMsg
    '        End If
    '        Me.lbl_mainStatsBar.Refresh()

    '        .Txt_Log.SelectionStart = .Txt_Log.Text.Length
    '        Me.Txt_Log.Refresh()
    '        Me.Txt_Log.ScrollToCaret()

    '        Dim LastScript() As String = Split(Me.Txt_Log.Text, "START>>")
    '        If InStr((LastScript(UBound(LastScript))), "ERROR...") > 0 Then
    '            .Txt_Log.ForeColor = Color.FromArgb(196, 0, 0)
    '        ElseIf InStr((LastScript(UBound(LastScript))), "CANCELLED by User") > 0 Then
    '            .Txt_Log.ForeColor = Color.FromArgb(196, 0, 0)
    '        ElseIf LogMsg = "<<END" And Me.Txt_Log.ForeColor <> Color.FromArgb(196, 0, 0) Then
    '            .Txt_Log.ForeColor = Color.FromArgb(1, 222, 0)
    '        End If
    '    End With


    'End Sub


    Private Sub Bt_CopyLog_Click(sender As Object, e As EventArgs) Handles Bt_CopyLog.Click
        '    If Control.ModifierKeys = Keys.Alt Then
        '        Try
        '            Dim flePath As String = XMLPath & "\Log_" & Format(Now(), "mmddyy_hhmmss") & ".txt"
        '            Dim NewFle = System.IO.File.CreateText(flePath)
        '            NewFle.WriteLine(Me.Txt_Log.Text)
        '            NewFle.Close()
        '            Process.Start("notepad.exe", flePath)
        '        Catch ex As Exception
        '            UpdateLog(True, "ERROR..." & Err.Description)
        '        End Try
        '        Exit Sub
        '    End If
        '    Me.pb_mainProcess.Value = 0
        '    If Me.Txt_Log.Text <> "" Then Clipboard.SetText(Me.Txt_Log.Text)
    End Sub

    Private Sub cmbxMoveTo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbxMoveTo.SelectedIndexChanged
        Global_txbxMoveTo = Me.cmbxMoveTo.Text
    End Sub

    Private Sub cmbxRetriveFrom_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbxRetriveFrom.SelectedIndexChanged
        Global_txbxRetriveFrom = Me.cmbxRetriveFrom.Text
    End Sub

    Private Sub txbx_FromEmailFilter_TextChanged(sender As Object, e As EventArgs) Handles txbx_FromEmailFilter.TextChanged

    End Sub
End Class