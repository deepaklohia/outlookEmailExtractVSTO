﻿Friend Class CurrentInstance
End Class
